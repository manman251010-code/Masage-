# Quizogram — Bothost (zip-деплой)

Один Node.js-процесс: Mini App (public/index.html) + /api/auth + бот (long polling).
Тариф Firebase Blaze и Functions не нужны.

## Что подготовить
1. Firebase Console → Project settings → Service accounts → Generate new private key.
   Скачанный JSON положи в корень как `serviceAccount.json` (или вставь содержимое одной строкой в переменную `FIREBASE_SERVICE_ACCOUNT`).
2. Токен бота от @BotFather.
3. Firebase Console → Firestore → Rules: вставь содержимое firestore.rules → Publish.
4. Authentication → Get started.

## Настройка
Переменные окружения на Bothost (или файл config.json рядом с server.js):
- `BOT_TOKEN` — токен бота
- `APP_URL` — публичный https-адрес, где открывается этот сервер
- `PORT` — если Bothost задаёт порт сам, оставь как есть

config.json (если нет переменных):
{ "BOT_TOKEN": "123:ABC", "APP_URL": "https://....bothost.ru" }

## Деплой
Заархивируй содержимое папки (server.js, package.json, public/, serviceAccount.json) и загрузи zip на Bothost.
Команда запуска: `npm start` (или `node server.js`).

В @BotFather → Bot Settings → Menu Button → URL = APP_URL.

## Если у Bothost нет публичного https-адреса
Залей только папку public на Firebase Hosting (бесплатно на Spark): `firebase deploy --only hosting`,
впиши адрес бота в `API_BASE` в public/index.html, а `APP_URL` = адрес Firebase Hosting.

serviceAccount.json — секрет, никому не показывай и не публикуй.

## Режим без serviceAccount.json
Если ключа нет, сервер работает как бот + статика, а приложение входит через анонимную авторизацию Firebase.
Нужно включить: Firebase Console → Authentication → Sign-in method → Anonymous → Enable.
Минус: аккаунт привязан к браузеру Telegram, а не к Telegram ID, и подпись initData не проверяется.
