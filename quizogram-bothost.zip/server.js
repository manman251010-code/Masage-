// Quizogram: один процесс = Mini App (статика) + /api/auth + Telegram-бот (long polling).
// Переменные окружения (или config.json рядом, см. README):
//   BOT_TOKEN, APP_URL, FIREBASE_SERVICE_ACCOUNT (JSON одной строкой) | файл serviceAccount.json, PORT
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const admin = require("firebase-admin");

let cfg = {};
try { cfg = JSON.parse(fs.readFileSync(path.join(__dirname, "config.json"), "utf8")); } catch {}
const BOT_TOKEN = process.env.BOT_TOKEN || cfg.BOT_TOKEN;
const APP_URL = process.env.APP_URL || cfg.APP_URL || "https://quizogram-f0616.web.app";
const PORT = process.env.PORT || cfg.PORT || 3000;
if (!BOT_TOKEN) { console.error("Нет BOT_TOKEN"); process.exit(1); }

let hasKey = false;
try {
  const sa = process.env.FIREBASE_SERVICE_ACCOUNT
    ? JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)
    : JSON.parse(fs.readFileSync(path.join(__dirname, "serviceAccount.json"), "utf8"));
  admin.initializeApp({ credential: admin.credential.cert(sa) });
  hasKey = true;
} catch { console.warn("Ключа Firebase нет: /api/auth отключён, вход идёт через анонимную авторизацию"); }

// ---- проверка подписи Telegram initData ----
function verify(initData) {
  const p = new URLSearchParams(initData);
  const hash = p.get("hash");
  if (!hash) return null;
  p.delete("hash");
  const str = [...p.entries()].map(([k, v]) => `${k}=${v}`).sort().join("\n");
  const secret = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
  const calc = crypto.createHmac("sha256", secret).update(str).digest("hex");
  if (calc.length !== hash.length || !crypto.timingSafeEqual(Buffer.from(calc), Buffer.from(hash))) return null;
  if (Date.now() / 1000 - Number(p.get("auth_date")) > 86400) return null;
  try { return JSON.parse(p.get("user")); } catch { return null; }
}

// ---- HTTP: статика + /api/auth ----
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml", ".json": "application/json", ".ico": "image/x-icon", ".webp": "image/webp" };
const PUB = path.join(__dirname, "public");

http.createServer(async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
  if (req.method === "OPTIONS") return res.writeHead(204).end();

  const url = new URL(req.url, "http://x");
  if (url.pathname === "/api/auth" && req.method === "POST") {
    if (!hasKey) return res.writeHead(503).end();
    let body = "";
    for await (const c of req) { body += c; if (body.length > 1e5) return res.writeHead(413).end(); }
    let initData = "";
    try { initData = String(JSON.parse(body).initData || ""); } catch {}
    const user = verify(initData);
    if (!user) return res.writeHead(401, { "Content-Type": "application/json" }).end('{"error":"bad initData"}');
    try {
      const token = await admin.auth().createCustomToken(String(user.id), { username: user.username || null });
      return res.writeHead(200, { "Content-Type": "application/json" }).end(JSON.stringify({ token }));
    } catch (e) {
      console.error("auth error", e.message);
      return res.writeHead(500).end();
    }
  }

  if (req.method !== "GET") return res.writeHead(405).end();
  let rel = decodeURIComponent(url.pathname);
  if (rel === "/") rel = "/index.html";
  const file = path.normalize(path.join(PUB, rel));
  if (!file.startsWith(PUB) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) return res.writeHead(404).end("Not found");
  res.writeHead(200, { "Content-Type": MIME[path.extname(file)] || "application/octet-stream" });
  fs.createReadStream(file).pipe(res);
}).listen(PORT, () => console.log("HTTP on", PORT));

// ---- Telegram-бот (long polling) ----
const API = `https://api.telegram.org/bot${BOT_TOKEN}`;
const tg = (m, b) => fetch(`${API}/${m}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b) }).then(r => r.json());

async function poll() {
  await tg("deleteWebhook", {});
  let offset = 0;
  for (;;) {
    try {
      const r = await tg("getUpdates", { offset, timeout: 30, allowed_updates: ["message"] });
      for (const u of r.result || []) {
        offset = u.update_id + 1;
        const m = u.message;
        if (m?.text?.startsWith("/start")) {
          await tg("sendMessage", {
            chat_id: m.chat.id,
            text: "Добро пожаловать в Quizogram ✨",
            reply_markup: { inline_keyboard: [[{ text: "Открыть Quizogram", web_app: { url: APP_URL } }]] },
          });
        }
      }
    } catch (e) { console.error("poll error", e.message); await new Promise(r => setTimeout(r, 3000)); }
  }
}
poll();
